<?php

class smotik_db {

    private static $instance = null;
    
    private function __clone() {
        
    }

    private function __construct() {
        
    }
    
    public static function getInstance() {
         try {
            $conn = new PDO('mysql:host=sql313.epizy.com;dbname=epiz_20424177_smotik;charset=utf8', 'epiz_20424177', 'twtAJmE8');
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            if(!isset(self::$instance)){
                self::$instance = $conn;
            }
            return self::$instance;
        } catch (Exception $e) {
            die('Erreur : ' . $e->getMessage());
        }
    }

}
