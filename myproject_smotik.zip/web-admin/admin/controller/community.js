myapp.controller('communityCtrl', ['$scope', function($scope){
	
}])