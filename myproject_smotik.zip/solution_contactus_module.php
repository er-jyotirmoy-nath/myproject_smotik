 <section id="contact">
        <div class="container" ng-controller="solutioncontactCtrl">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Contact Us</h2>
                    
                </div>
            </div>
           <solution-contact productlist="products" filter="filter_prod" ></solution-contact>
        </div>
</section>