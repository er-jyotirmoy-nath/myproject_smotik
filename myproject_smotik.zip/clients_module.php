<div class="container">
            <h2 class="hdg">Our Clients</h2>
            <div class="row container-padd">
                <?php $new_web_load->getclientdetails(); ?>
            </div>
        </div>