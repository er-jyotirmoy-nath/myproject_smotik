 <?php require_once 'model/solutions_model.php'; ?>
        <div class="container inner-height">

            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Customer Service</h1>
                </div>
                <div class="col-md-6"><img class="img-responsive" src="img/happy-customer.jpg" alt=""></div>
                <?php $new_page->getCustomerServicePage('customerservice'); ?>
            </div>

        </div>

        <hr />

        <div class="container">
            <h3 class="hdgg">Happy SMOTIK Communities</h3>
            <div class="col-md-12 abt-txtt">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            </div>

            <div class="row container-padd">
                <div class="col-sm-3 col-xs-6"><img src="img/img2.jpg" class="img-thumbnail" alt=""/></div>
                <div class="col-sm-3 col-xs-6"><img src="img/img2.jpg" class="img-thumbnail" alt=""/></div>
                <div class="col-sm-3 col-xs-6"><img src="img/img2.jpg" class="img-thumbnail" alt=""/></div>
                <div class="col-sm-3 col-xs-6"><img src="img/img2.jpg" class="img-thumbnail" alt=""/></div>
            </div>
        </div>